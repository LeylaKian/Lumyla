LUMYLA Creative Digital Studio — static website export
=======================================================

WHAT THIS IS
------------
The production build of the LUMYLA website: pre-built HTML, CSS, JavaScript,
fonts, brand files and media (including the scroll-driven hero video).

  index.html          the single HTML entry point
  assets/*.css        all site styles (design tokens, sections, components)
  assets/*.js         the compiled site JavaScript (navigation, animations, forms)
  fonts/              Vazirmatn webfonts
  brand/              logo, favicon, hero photo
  media/              hero video (MP4, desktop + mobile) and poster frame

IMPORTANT: HOW THIS SITE WORKS
------------------------------
This is a single-page application. index.html is the only HTML file and the
JavaScript renders every page (home, services, portfolio, journal, pricing,
about, contact, case studies).

That means the server must send index.html for ANY path, otherwise a direct
visit to a sub-page returns 404:

  Apache      -> keep the included .htaccess file
  Netlify     -> keep the included _redirects file
  Nginx       -> add:  try_files $uri $uri/ /index.html;
  WordPress   -> do not use this ZIP; use the WordPress theme ZIP instead

Always serve the folder over HTTP. Opening index.html directly from the file
system (file://) will not work.

WHAT IS NOT INCLUDED
--------------------
The static build has no server, so the consultation form's lead capture has
no backend endpoint. Its validation and interface still work, but submissions
are not stored. To keep working lead capture, either:
  - use the WordPress theme export (leads are saved as a WordPress post type), or
  - point the form at your own API by editing src/components/forms/ConsultationForm.jsx
    and rebuilding.

EDITING
-------
This ZIP is compiled output. To change content or design, edit the project
source in the repository and rebuild with:  npm install && npm run build
